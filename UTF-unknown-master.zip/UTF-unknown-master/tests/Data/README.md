These text fragments have been copied taken from the following sources:

- Wikipedia - http://wikipedia.org
- Project Gutenberg - http://www.gutenberg.org

The test files are automatically discovered. 
The directory name should be the expected encoding. 
If there is a `(`, then it's the name before it.
